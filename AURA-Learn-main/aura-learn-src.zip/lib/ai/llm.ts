import type { AiConfig } from "./env";

/**
 * Reusable chat-completion client for OpenRouter (and any OpenAI-compatible endpoint).
 * SERVER ONLY: it holds the API key. Nothing in components/ imports this file.
 */
if (typeof window !== "undefined") throw new Error("lib/ai/llm.ts must never be bundled for the browser");

export interface ChatMessage {
  role: "system" | "user";
  content: string;
}

export type LlmErrorKind = "timeout" | "http_error" | "invalid_response" | "network";

export class LlmError extends Error {
  constructor(public kind: LlmErrorKind, message: string, public status?: number) {
    super(message);
    this.name = "LlmError";
  }
}

export interface LlmClient {
  readonly model: string;
  complete(messages: ChatMessage[], opts?: { timeoutMs?: number }): Promise<{ text: string }>;
}

/** Remove anything that looks like a secret from text that might be logged or returned. */
export function redact(text: string, secret?: string): string {
  let out = text.replace(/(?:sk|or)-[A-Za-z0-9_\-]{8,}/g, "[redacted]");
  if (secret) out = out.split(secret).join("[redacted]");
  return out;
}

export function createOpenRouterClient(cfg: AiConfig, fetchImpl: typeof fetch = fetch): LlmClient {
  const apiKey = cfg.apiKey;
  if (!apiKey) throw new Error("OPENROUTER_API_KEY is not set");
  return {
    model: cfg.model,
    async complete(messages, opts = {}) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), opts.timeoutMs ?? cfg.timeoutMs);
      try {
        const res = await fetchImpl(`${cfg.baseUrl}/chat/completions`, {
          method: "POST",
          signal: controller.signal,
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${apiKey}`,
            "HTTP-Referer": "https://aura-learn.local",
            "X-Title": "AURA Learn",
          },
          body: JSON.stringify({ model: cfg.model, messages, temperature: 0.7, max_tokens: 400, response_format: { type: "json_object" } }),
        });
        if (!res.ok) {
          const body = await res.text().catch(() => "");
          throw new LlmError("http_error", `Model API returned ${res.status}: ${redact(body.slice(0, 160), apiKey)}`, res.status);
        }
        const json = (await res.json().catch(() => null)) as { choices?: { message?: { content?: unknown } }[] } | null;
        const text = json?.choices?.[0]?.message?.content;
        if (typeof text !== "string" || !text.trim()) throw new LlmError("invalid_response", "Model API returned no text");
        return { text };
      } catch (e) {
        if (e instanceof LlmError) throw e;
        if (e instanceof Error && e.name === "AbortError") throw new LlmError("timeout", "Model API timed out");
        throw new LlmError("network", redact(e instanceof Error ? e.message : "Network error", apiKey));
      } finally {
        clearTimeout(timer);
      }
    },
  };
}
