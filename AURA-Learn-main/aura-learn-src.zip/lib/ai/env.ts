import type { AiMode } from "./types";

/**
 * AI configuration, read from environment variables on the server only.
 * The API key is never sent to the browser: this module is imported by API routes, not by client components.
 */
export interface AiConfig {
  mode: AiMode;
  apiKey?: string;
  baseUrl: string;
  model: string;
  timeoutMs: number;
  maxPerMinute: number;
}

const MODES: AiMode[] = ["auto", "template", "off"];

export function readAiConfig(env: Record<string, string | undefined> = process.env): AiConfig {
  const mode = MODES.includes(env.AI_RETHEME_MODE as AiMode) ? (env.AI_RETHEME_MODE as AiMode) : "auto";
  return {
    mode,
    apiKey: env.OPENROUTER_API_KEY?.trim() || undefined,
    baseUrl: (env.OPENROUTER_BASE_URL?.trim() || "https://openrouter.ai/api/v1").replace(/\/+$/, ""),
    model: env.OPENROUTER_MODEL?.trim() || "openai/gpt-4o-mini",
    timeoutMs: Math.max(1000, Number(env.AI_TIMEOUT_MS) || 7000),
    maxPerMinute: Math.max(1, Number(env.AI_MAX_CALLS_PER_MINUTE) || 30),
  };
}

/** Whether the live model can be called at all. False means the built-in themes are used. */
export function aiConfigured(cfg: AiConfig): boolean {
  return cfg.mode === "auto" && !!cfg.apiKey;
}
