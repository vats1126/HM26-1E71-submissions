import { getStore, mutate } from "../db";
import type { ThemeCache } from "./retheme";
import { readAiConfig, aiConfigured, type AiConfig } from "./env";
import { createOpenRouterClient, type LlmClient } from "./llm";
import { CircuitBreaker, RateLimiter } from "./resilience";
import { rethemeQuestion, type RethemeInput } from "./retheme";
import type { RethemeResult } from "./types";

/**
 * Wiring for the running app: config from env, the model client, and the shared breaker and limiter.
 * API routes call rethemeWithApp(); tests build their own deps and call rethemeQuestion() directly.
 */

const g = globalThis as unknown as { __auraAi?: { breaker: CircuitBreaker; limiter: RateLimiter; limiterMax: number } };

function shared(cfg: AiConfig) {
  if (!g.__auraAi || g.__auraAi.limiterMax !== cfg.maxPerMinute) {
    g.__auraAi = { breaker: new CircuitBreaker({ threshold: 3, cooldownMs: 60_000 }), limiter: new RateLimiter({ max: cfg.maxPerMinute }), limiterMax: cfg.maxPerMinute };
  }
  return g.__auraAi;
}

const storeCache: ThemeCache = {
  get: (key) => getStore().themeCache.find((e) => e.key === key),
  put: (entry) =>
    mutate((s) => {
      s.themeCache = [...s.themeCache.filter((e) => e.key !== entry.key), entry].slice(-300);
    }),
};

let client: { key: string; llm: LlmClient } | null = null;
function llmFor(cfg: AiConfig): LlmClient | null {
  if (!aiConfigured(cfg)) return null;
  const id = `${cfg.baseUrl}|${cfg.model}|${cfg.apiKey}`;
  if (!client || client.key !== id) client = { key: id, llm: createOpenRouterClient(cfg) };
  return client.llm;
}

export async function rethemeWithApp(input: RethemeInput): Promise<RethemeResult> {
  try {
    const config = readAiConfig();
    const { breaker, limiter } = shared(config);
    return await rethemeQuestion(input, { config, cache: storeCache, llm: llmFor(config), breaker, limiter });
  } catch {
    // Belt and braces: whatever went wrong, the student still gets the original question.
    return rethemeQuestion({ ...input, mode: "off" }, { config: { ...readAiConfig(), mode: "off" }, cache: { get: () => undefined, put: () => undefined } });
  }
}

/** Non-secret status for the UI. Never includes the key. */
export function aiStatus() {
  const config = readAiConfig();
  const { breaker } = shared(config);
  const configured = aiConfigured(config);
  return {
    mode: config.mode,
    configured,
    model: configured ? config.model : null,
    serviceState: !configured ? ("not_configured" as const) : breaker.state === "open" ? ("paused" as const) : ("ready" as const),
    label: config.mode === "off" ? "Re-theming is off" : configured ? `AI re-theming ready (${config.model})` : "Built-in themes (no AI key configured)",
  };
}
