import { ThemeStudio, type StudioSample } from "@/components/ai/ThemeStudio";
import { PageHeader } from "@/components/ui/PageHeader";
import { aiStatus } from "@/lib/ai";
import { requireUser } from "@/lib/auth";
import { getStore } from "@/lib/db";

export const metadata = { title: "AURA AI" };
export const dynamic = "force-dynamic";

/** Numeric questions with clear before and after: the PRD example first. */
const SAMPLE_IDS = ["ohms-law-l2-1", "ohms-law-l3-1", "ohms-law-l4-1", "electric-current-l2-1", "voltage-l3-1", "resistance-l3-1", "ph-l3-1", "titration-l3-1"];

export default async function AiPage() {
  await requireUser("student");
  const store = getStore();
  const topics = new Map(store.topics.map((t) => [t.id, t.name]));
  const samples: StudioSample[] = SAMPLE_IDS.map((id) => store.questions.find((q) => q.id === id))
    .filter((q): q is NonNullable<typeof q> => !!q)
    .map((q) => ({ id: q.id, stem: q.stem, topic: topics.get(q.topicId) ?? q.topicId, level: q.level, objective: q.objective, unit: q.unit }));
  const status = aiStatus();

  return (
    <div className="page py-8 lg:py-10">
      <PageHeader
        eyebrow="AURA AI"
        title="Same problem, your story"
        description="AURA rewrites the story around what you love and leaves the science untouched. Every version is checked before you see it."
      />
      <ThemeStudio
        samples={samples}
        defaultId={samples[0].id}
        status={{ configured: status.configured, label: status.label, model: status.model, mode: status.mode }}
        allowReveal={process.env.AURA_ALLOW_ANSWER_REVEAL !== "false"}
      />
    </div>
  );
}
