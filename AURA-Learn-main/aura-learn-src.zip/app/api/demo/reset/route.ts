import { ok, fail } from "@/lib/api";
import { getCurrentUser } from "@/lib/auth";
import { resetStore } from "@/lib/db";

export const dynamic = "force-dynamic";

/** Restore the seeded demo story. Requires a signed-in demo user. */
export async function POST() {
  const user = await getCurrentUser();
  if (!user) return fail("Not signed in", 401);
  const store = resetStore();
  return ok({ reset: true, users: store.users.length });
}
