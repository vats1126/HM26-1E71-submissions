import { LayoutDashboard } from "lucide-react";
import { Greeting } from "@/components/shell/Greeting";
import { Badge } from "@/components/ui/Badge";
import { Card } from "@/components/ui/Card";
import { EmptyState } from "@/components/ui/EmptyState";
import { PageHeader } from "@/components/ui/PageHeader";
import { requireUser } from "@/lib/auth";

export const metadata = { title: "Overview" };

export default async function FacilitatorHome() {
  const user = await requireUser("facilitator");
  const surname = user.name.split(" ").at(-1) ?? user.name;
  return (
    <div className="page py-8 lg:py-10">
      <PageHeader
        eyebrow="Class 9A"
        title={<Greeting name={`Ms. ${surname}`} />}
        description="Here's how your class is doing today."
      />
      <Card padding="none" className="enter" style={{ ["--i" as string]: 1 }}>
        <EmptyState
          icon={LayoutDashboard}
          title="Your class overview is coming"
          description="Live counts and the intervention queue appear here once the facilitator dashboard is built."
          action={<Badge tone="accent">F13 · Facilitator dashboard</Badge>}
        />
      </Card>
    </div>
  );
}
