import { ShieldAlert } from "lucide-react";
import { PlannedPage } from "@/components/shell/PlannedPage";

export const metadata = { title: "Intervention Queue" };

export default function Page() {
  return (
    <PlannedPage
      eyebrow="Intervention Queue"
      title="Intervention Queue"
      description="Students AURA thinks need a human, ranked by urgency, with the reason why."
      icon={ShieldAlert}
      feature="F13 · Intervention queue"
    />
  );
}
