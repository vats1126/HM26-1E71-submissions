import { Users } from "lucide-react";
import { PlannedPage } from "@/components/shell/PlannedPage";

export const metadata = { title: "Students" };

export default function Page() {
  return (
    <PlannedPage
      eyebrow="Students"
      title="Students"
      description="Everyone in your class, with mastery and risk at a glance."
      icon={Users}
      feature="P1 · Students list"
    />
  );
}
